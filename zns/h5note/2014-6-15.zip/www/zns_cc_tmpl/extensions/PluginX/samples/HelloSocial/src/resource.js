var s_CloseNormal = "res/CloseNormal.png";
var s_CloseSelected = "res/CloseSelected.png";
var s_Background = "res/Background.png";
var s_qzone = "res/qzone.gif";
var s_snweibo = "res/snweibo.gif";
var s_qqweibo = "res/qqweibo.gif";
var s_facebook = "res/facebook.gif";
var s_twitter = "res/twitter.gif";

var g_ressources = [
    {src:s_CloseNormal},
    {src:s_CloseSelected},
    {src:s_Background},
    {src:s_qzone},
    {src:s_facebook},
    {src:s_twitter},
    {src:s_qqweibo},
    {src:s_snweibo}
];