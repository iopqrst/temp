/**
 * Created by blue on 14-6-15.
 */

var Fish=cc.Sprite.extend({
    ctor:   function (type)     //cc的构造函数
    {
        this._super();

        var fileName=window['s_fish'+type];

        //初始图片
        var arrSize=[
            null,
            cc.rect(0,0,55,37),
            cc.rect(0,0,78,64),
            cc.rect(0,0,72,56),
            cc.rect(0,0,77,59),
            cc.rect(0,0,107,122)
        ];
        this.initWithFile(fileName, arrSize[type]);

        //动画
        var animation=cc.Animation.create();

        for(var i=0;i<4;i++)
        {
            var r=arrSize[type];

            var frame=cc.SpriteFrame.create(fileName, cc.rect(
                0, i*r.height,
                r.width, r.height
            ));

            animation.addSpriteFrame(frame);
        }

        animation.setDelayPerUnit(0.1);
        animation.setLoops(Number.MAX_VALUE);

        var animate=cc.Animate.create(animation);

        this.runAction(animate);
    }
});









