/*
* 所有需要加载的文件，都放这儿——图片、声音、动画、模型...*/

var s_fish1='fish1.png';
var s_fish2='fish2.png';
var s_fish3='fish3.png';
var s_fish4='fish4.png';
var s_fish5='fish5.png';
var s_web7='web7.png';
var s_cannon1='cannon1.png';
var s_cannon2='cannon2.png';
var s_cannon3='cannon3.png';
var s_cannon4='cannon4.png';
var s_cannon5='cannon5.png';
var s_cannon6='cannon6.png';
var s_cannon7='cannon7.png';

 var g_resources = [
    /*{src: 文件名}*/
     {src: s_fish1},
     {src: s_fish2},
     {src: s_fish3},
     {src: s_fish4},
     {src: s_fish5},
     {src: s_web7},
     {src: s_cannon1},
     {src: s_cannon2},
     {src: s_cannon3},
     {src: s_cannon4},
     {src: s_cannon5},
     {src: s_cannon6},
     {src: s_cannon7}
];