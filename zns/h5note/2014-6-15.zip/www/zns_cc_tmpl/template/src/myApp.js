var MyScene = cc.Scene.extend({
    onEnter:function () {
        //整个程序开始的地方

        this._super();

        var g=new Gun(7);
        g.setPosition(cc.p(this.getContentSize().width/2, 40));
        this.addChild(g);
    }
});
