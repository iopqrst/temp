/**
 * Created by blue on 14-6-15.
 */

var Gun=cc.Sprite.extend({
    ctor:       function (type)
    {
        this._super();

        var fileName=window['s_cannon'+type];
        var arrSize=[
            null,
            cc.rect(0,0,74,74),
            cc.rect(0,0,74,76),
            cc.rect(0,0,74,76),
            cc.rect(0,0,74,83),
            cc.rect(0,0,74,85),
            cc.rect(0,0,74,90),
            cc.rect(0,0,74,94)
        ];

        this.initWithFile(fileName, arrSize[type]);

        //加事件
        //cc.Director.getInstance().getTouchDispatcher()._addTargetedDelegate(this, 0);
        var 导演=cc.Director.getInstance();
        导演.getTouchDispatcher()._addTargetedDelegate(this, 0);      //小-高
    },
    onTouchBegan:   function (ev)
    {
        var p=this.getPosition();
        var p2=ev.getLocation();

        var a=p.x-p2.x;
        var b=p2.y-p.y;

        var ang=-Math.atan2(a, b)*180/Math.PI;

        this.runAction(cc.RotateTo.create(0.05, ang));
    }
});